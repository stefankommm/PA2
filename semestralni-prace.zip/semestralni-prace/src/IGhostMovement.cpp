//
// Created by stefam on 14. 5. 2023.
//

#include "IGhostMovement.h"
#include <utility>
#include <deque>
#include <queue>


pair<int, int> getNextPosition(const pair<int, int> &position, Direction direction) {
    int newRow = position.second;
    int newCol = position.first;

    switch (direction) {
        case Direction::Up:
            newRow--;
            break;
        case Direction::Down:
            newRow++;
            break;
        case Direction::Left:
            newCol--;
            break;
        case Direction::Right:
            newCol++;
            break;
    }
    return make_pair(newCol, newRow);
}


void IGhostMovement::moveFromSpawn(Ghost &ghost) {
    pair<int, int> ghostPosition = ghost.getPosition();
    pair<int, int> navigatingTo = board.getBorderToCross();
    pair<int, int> oldSur = ghostPosition;
    pair<int, int> nextSur = ghostPosition;

    if (ghostPosition.first < navigatingTo.first)
        direction = Direction::Right;
    else if (ghostPosition.first > navigatingTo.first)
        direction = Direction::Left;
    else if (ghostPosition.second < navigatingTo.second)
        direction = Direction::Down;
    else if (ghostPosition.second > navigatingTo.second)
        direction = Direction::Up;

    nextSur = getNextPosition(oldSur, direction);
    CellType nextCellType = board.at(nextSur);

    if (board.at(oldSur) == CellType::Border) {
        if (nextCellType == CellType::Spawn || nextCellType == CellType::Wall) {
            // Vyber smer ak je stena
            vector<Direction> alternativeDirections;
            for (const auto &dir: AllDirections) {
                pair<int, int> newPos = getNextPosition(ghostPosition, dir);
                CellType newPosType = board.at(newPos);
                if (board.isInArea(newPos) && newPosType != CellType::Spawn && newPosType != CellType::Wall &&
                    newPosType != CellType::Border) {
                    alternativeDirections.push_back(dir);
                }
            }
            // Nahodne vyber smer
            if (!alternativeDirections.empty()) {
                size_t randomIndex = rand() % alternativeDirections.size();
                direction = alternativeDirections[randomIndex];
                nextSur = getNextPosition(ghostPosition, direction);
            } else {
                // Niet uteku
                return;
            }
            ghost.setIsAtHome(false);
        }
    } else {
        if (nextCellType == CellType::Wall) {
            // Vyber smer ak je stena
            vector<Direction> alternativeDirections;
            for (const auto &dir: AllDirections) {
                pair<int, int> newPos = getNextPosition(ghostPosition, dir);
                CellType newPosType = board.at(newPos);
                if (board.isInArea(newPos) && newPosType != CellType::Wall) {
                    alternativeDirections.push_back(dir);
                }
            }
            // Nahodne vyber smer
            if (!alternativeDirections.empty()) {
                size_t randomIndex = rand() % alternativeDirections.size();
                direction = alternativeDirections[randomIndex];
                nextSur = getNextPosition(ghostPosition, direction);
            } else {
                // Niet uteku
                return;
            }
        }
    }
    ghost.setPosition(nextSur);

}


void RandomMovement::move(Ghost &ghost) {

}

void DumbMovement::move(Ghost &ghost) {
    pair<int, int> ghostPosition = ghost.getPosition();
    pair<int, int> nextPos;

    vector<Direction> validDirections;
    for (const auto &dir: AllDirections) {
        nextPos = getNextPosition(ghostPosition, dir);
        if (board.isInArea(nextPos) && board.at(nextPos) != CellType::Wall && board.at(nextPos) != CellType::Border && !hasBeenRecently(nextPos)) {
            validDirections.push_back(dir);
        }
    }

    // If there are no valid directions (new positions to visit), reset memory and try again
    if (validDirections.empty()) {
        recentPositions.clear();
        for (const auto &dir: AllDirections) {
            nextPos = getNextPosition(ghostPosition, dir);
            if (board.isInArea(nextPos) && board.at(nextPos) != CellType::Wall && board.at(nextPos) != CellType::Border) {
                validDirections.push_back(dir);
            }
        }
    }

    // If there are still no valid directions after memory reset, the ghost is completely trapped. Do nothing.
    if (validDirections.empty()) {
        return;
    }

    // Choose a valid direction
    size_t randomIndex = rand() % validDirections.size();
    direction = validDirections[randomIndex];
    rememberPosition(ghostPosition); // Before moving to new position, remember the current one

    // Get the new position after choosing the direction
    nextPos = getNextPosition(ghostPosition, direction);
    ghost.setPosition(nextPos);
}

void DumbMovement::rememberPosition(const pair<int, int> &pos) {
    if (recentPositions.size() >= 20) {  // check if the deque has 20 or more elements
        recentPositions.pop_front();  // remove the oldest element
    }
    recentPositions.push_back(pos);  // add the new position at the end
}

bool DumbMovement::hasBeenRecently(const pair<int, int> &pos) {
    return std::find(recentPositions.begin(), recentPositions.end(), pos) != recentPositions.end();
}


void SmartMovement::move(Ghost &ghost) {
    std::queue<std::pair<int, int>> q;
    std::map<std::pair<int, int>, std::pair<int, int>> prev;

    auto pacmanPosition = board.getPacmanPosition();
    auto start = ghost.getPosition();

    q.push(start);

    while(!q.empty()) {
        auto curr = q.front();
        q.pop();

        if(curr == pacmanPosition) {
            std::vector<std::pair<int, int>> path;

            for(auto i = curr; i != start; i = prev[i]) {
                path.push_back(i);
            }
            path.push_back(start);
            std::reverse(path.begin(), path.end());

            if(path.size() > 1) {
                auto nextPosition = path[1];
                if(nextPosition.first < start.first)
                    direction = Direction::Left;
                else if(nextPosition.first > start.first)
                    direction = Direction::Right;
                else if(nextPosition.second < start.second)
                    direction = Direction::Up;
                else if(nextPosition.second > start.second)
                    direction = Direction::Down;

                ghost.setPosition(nextPosition);
            }
            return;
        }

        for(const auto &dir : AllDirections) {
            auto nextPos = getNextPosition(curr, dir);
            if (board.isInArea(nextPos) && board.at(nextPos) != CellType::Wall && board.at(nextPos) != CellType::Border && board.at(nextPos) != CellType::Teleport && prev.count(nextPos) == 0) {
                q.push(nextPos);
                prev[nextPos] = curr;
            }
        }
    }
}



