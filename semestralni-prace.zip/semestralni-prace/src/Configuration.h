//
// Created by stefam on 14. 5. 2023.
//

#pragma once

#include <string>
#include <fstream>
#include <vector>
#include <map>
#include "constants.h"

using namespace std;
class Configuration {
public:
    static std::vector<std::vector<CellType>> loadMapFromFile(const string & mapLocation);
    static LevelSettings loadConfiguration (int difficulty);
};

